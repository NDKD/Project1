INSERT INTO products (name, ticker)
VALUES 
	   ('Bitcoin', 'BTC-USD'),
	   ('Ethereum', 'ETH-USD'),
	   ('Stellar', 'XLM-USD'),
	   ('Litecoin', 'LTC-USD'),
	   ('Dash', 'DASH-USD');